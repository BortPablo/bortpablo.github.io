import reflex as rx

class ReflextestConfig(rx.Config):
    pass

config = ReflextestConfig(
    app_name="reflex_test",
    port=3000,
)